import math

# --- Configuration ---
MIN_TEMP_C = -10
MAX_TEMP_C = 150
LUT_SIZE = 2048

# --- Physics & Scaling ---
# We need to map T^4 (Energy) into the LUT indices [0 to 2047].
# Max Energy (at 300C) is approx 1.08 * 10^11.
# To fit this into index 2048, we need a large bit shift.


def generate_header():
    print(f"Generating LUT for range {MIN_TEMP_C}C to {MAX_TEMP_C}C...")

    # 1. Calculate the maximum theoretical energy (T_kelvin ^ 4)
    max_k = MAX_TEMP_C + 273.15
    max_energy = math.pow(max_k, 4)

    # 2. Calculate the required shift to fit this huge number into our LUT_SIZE
    # index = energy >> SHIFT  =>  SHIFT = log2(energy / LUT_SIZE)
    required_shift = math.log2(max_energy / LUT_SIZE)
    # Round up to nearest integer for bit-shifting stability
    lut_scale_shift = int(math.ceil(required_shift))

    print(f"  > Max Energy: {max_energy:.2e}")
    print(f"  > Calculated Shift: >> {lut_scale_shift} (keeps energy within LUT index)")

    with open("include/lut_data.h", "w") as f:
        f.write("// Automatically generated 4th-root Lookup Table\n")
        f.write("#ifndef __LUT_DATA_H__\n#define __LUT_DATA_H__\n\n")
        f.write("#include <stdint.h>\n\n")

        # Save these constants so the C code can stay synced
        f.write(f"#define TEMP_LUT_SIZE   {LUT_SIZE}\n")
        f.write(
            f"#define LUT_SCALE_SHIFT {lut_scale_shift} // Use this shift in your C code!\n"
        )
        f.write(f"// Range: {MIN_TEMP_C}C to {MAX_TEMP_C}C\n\n")

        f.write("const int16_t temp_lut[TEMP_LUT_SIZE] = {\n")

        for i in range(LUT_SIZE):
            # 1. Reverse the scaling: Energy = Index << Shift
            # We add 0.5 to 'i' to sample the center of the bin for better accuracy
            energy_approx = (i + 0.5) * (1 << lut_scale_shift)

            # 2. Physics: T_kelvin = Energy ^ 0.25
            temp_k = math.pow(energy_approx, 0.25)
            temp_c = temp_k - 273.15

            # 3. Clamp logic
            if temp_c < MIN_TEMP_C:
                temp_c = MIN_TEMP_C
            if temp_c > MAX_TEMP_C:
                temp_c = MAX_TEMP_C

            # 4. Convert to centi-degrees (int16)
            centi_c = int(temp_c * 100)

            f.write(f"    {centi_c}, ")
            if (i + 1) % 16 == 0:
                f.write("\n")

        f.write("};\n#endif // __LUT_DATA_H__\n")

    print(f"Done! Saved to include/lut_data.h")
    print(
        f"⚠️  IMPORTANT: Update your C code to use 'value >> {lut_scale_shift}' for the index."
    )


if __name__ == "__main__":
    generate_header()
