#include "mlx_process.h"
#include <string.h>

// Pre-computed LUT (Simplified for the example)
// In reality, populate this with: T = sqrt(sqrt(Index - Offset)) - 273.15
#include "mlx_lut.h"

// Global buffer to hold the state of the *previous* frame for dependency calculation
// (Some MLX calculations depend on the previous subpage's T_a or V_dd)
static mlx_frame_state_t frame_state;

// Fixed Point Macros
#define Q_SCALE 16
#define TO_FIXED(x) ((int32_t)((x) * (1 << Q_SCALE)))

void mlx_process_subpage(uint16_t *raw_data, mlx_params_t *params, uint8_t *usb_packet) {
    // 1. Read Status Register (stored at index 833 by our I2C driver)
    uint16_t status = raw_data[833];
    uint8_t  subpage = (status & 0x0001); // 0 or 1

    // 2. Prepare USB Packet Header
    usb_packet[0] = 0xDE;
    usb_packet[1] = 0xAD;
    usb_packet[2] = subpage;

    // Pointer to the payload section of the packet
    int16_t *payload_ptr = (int16_t *)&usb_packet[3];
    int      payload_index = 0;

    // 3. Ambient Temp (Ta) Calculation (Simplified Fixed Point)
    // Ta is required to compensate the pixel voltage
    int32_t v_ptat = (int32_t)raw_data[800];
    int32_t ta_fixed = (v_ptat - params->vPTAT25) * params->KtPTAT + params->vdd25;
    // Note: In full implementation, handle Vdd compensation here first.

    // 4. Calculate Emission Factor (Ta^4) using a small LUT or approximation
    // Since Ta range is small (-40 to 85), we can approximate Ta^4 easily.
    int32_t ta4_comp = (ta_fixed * ta_fixed) >> Q_SCALE; // Ta^2
    ta4_comp = (ta4_comp * ta4_comp) >> Q_SCALE;         // Ta^4

    // 5. Iterate over pixels
    // MLX90640 is 24x32. Total 768 pixels.
    // Subpage 0: Update pixels where (row + col) is even
    // Subpage 1: Update pixels where (row + col) is odd

    for (int i = 0; i < 768; i++) {
        int row = i / 32;
        int col = i % 32;

        // Check if this pixel belongs to the current subpage
        // Optimization: You can pre-calculate a list of indices for Page 0 vs 1
        // to avoid this modulo check every cycle.
        if (((row + col) % 2) == subpage) {

            // --- A. Offset Compensation ---
            int32_t pixel_val = (int32_t)raw_data[i];

            // Apply gain (Global gain stored in params)
            int32_t gain_comp = (pixel_val * params->gainEE) >> Q_SCALE;

            // Subtract individual pixel offset
            int32_t v_ir = gain_comp - params->offset[i];

            // --- B. Emissivity/Sensitivity Compensation (Alpha) ---
            // Vir_comp = Vir / (Alpha * Emissivity)
            // In Fixed point, division is slow. Try to use multiplication by inverse if possible.
            // Here we stick to simple division for clarity, but optimized:
            int32_t alpha = params->alpha[i];
            if (alpha == 0)
                alpha = 1; // Safety

            // This is the "Energy" value
            int32_t energy = (v_ir << 10) / alpha; // Scaling up for precision

            // Add Ambient energy contribution
            energy += ta4_comp;

            // --- C. LUT Conversion ---
            // Instead of sqrt(sqrt(energy)), we map it.
            // We scale energy to fit our LUT index logic
            int32_t lut_index = energy >> LUT_SCALE_SHIFT; // Adjust shift based on LUT_SCALE

            int16_t temp_c = lookup_temp(lut_index);

            // Write to Payload (384 pixels total)
            payload_ptr[payload_index++] = temp_c;
                }
    }
}