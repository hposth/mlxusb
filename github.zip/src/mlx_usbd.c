#include "mlx_usbd.h"

// #include "usbd_core.h"  // The main stack
#include "usb_def.h"        // Standard USB macros (USB_DEVICE_DESCRIPTOR_INIT, etc.)
#include "mlx_usb_config.h" // Your hardware specific config

// Configuration constants
#define CDC_IN_EP 0x81  // Endpoint 1 IN
#define CDC_OUT_EP 0x02 // Endpoint 2 OUT
#define CDC_INT_EP 0x83 // Endpoint 3 INT (Interrupt)

#define USBD_VID 0xFFFF
#define USBD_PID 0xFFFF
#define USBD_MAX_POWER 100
#define USBD_LANGID_STRING 1033

// #define IMAGE_SIZE (320 * 240 * 2) // Example: QVGA RGB565 (153.6 KB)
#define IMAGE_SIZE (32 * 24 * 1) // Example: MLX90640 frame (768 bytes)
#define PACKET_SIZE 64           // Max packet size for USB Full Speed

// Dummy buffer to simulate an image
uint8_t image_buffer[IMAGE_SIZE];

// #define USB_CONFIG_SIZE (9 + CDC_ACM_DESCRIPTOR_LEN)
#define USB_CONFIG_SIZE_TOTAL (USB_CONFIG_DESCRIPTOR_SIZE + USB_INTERFACE_DESCRIPTOR_SIZE + USB_ENDPOINT_DESCRIPTOR_SIZE + USB_ENDPOINT_DESCRIPTOR_SIZE)

#ifdef CONFIG_USB_HS
#define CDC_MAX_MPS 512
#else
#define CDC_MAX_MPS 64
#endif

/* USB Device Descriptor */
const uint8_t device_descriptor[] = {USB_DEVICE_DESCRIPTOR_INIT(USB_2_0, 0x00, 0x00, 0x00, 0xFFFF, 0xFFFF, 0x0100, 0x01)};

/* USB Configuration Descriptor */
const uint8_t config_descriptor[] = {
    USB_CONFIG_DESCRIPTOR_INIT(USB_CONFIG_SIZE_TOTAL, 1, 1, CONFIG_USB_POWER_SOURCE, 100), // Configuration
    USB_INTERFACE_DESCRIPTOR_INIT(0, 0, 2, 0xFF, 0x00, 0x00, 0),                           // Interface
    USB_ENDPOINT_DESCRIPTOR_INIT(CDC_IN_EP, USB_ENDPOINT_TYPE_BULK, PACKET_SIZE, 0x00),    // Endpoint IN
    USB_ENDPOINT_DESCRIPTOR_INIT(CDC_OUT_EP, USB_ENDPOINT_TYPE_BULK, PACKET_SIZE, 0x00)    // Endpoint OUT
};

/* String Descriptors */
const char *string_descriptors[] = {
    (const char[]){0x09, 0x04}, // Language ID
    "Manufacturer", // Manufacturer
    "ESP32-S3 Image Link", // Product
    "123456", // Serial Number
};

/* USB Callback: Data Sent */
void mlx_usbd_event_handler(uint8_t event) {
    if (event == USBD_EVENT_CONNECTED) {
        printf("USB Connected\n");
    }
}

const uint8_t busid = CONFIG_USB_DWC2_PORT;

TaskHandle_t mlx_usbd_task_handle = NULL;

void mlx_usbd_init() {
    // 1. Initialize image buffer with dummy data (gradient)
    for (int i = 0; i < IMAGE_SIZE; i++) {
        image_buffer[i] = (uint8_t)(i % 256);
    }

    // 2. Setup CherryUSB
    usbd_desc_register(busid, device_descriptor);
    usbd_desc_register(busid, config_descriptor);
    usbd_desc_register(busid, string_descriptors);

    // 3. Initialize the USB Hardware for ESP32-S3
    // Note: CherryUSB's S3 port handles the GPIO 19/20 routing internally
    usbd_initialize(busid, 0, mlx_usbd_event_handler);

    // Initialize Semaphores
    mlx_usbd_tx_ready = xSemaphoreCreateBinary();
    mlx_usbd_capture_ready = xSemaphoreCreateBinary();

    // Important: Give the capture signal initially so the camera can start the FIRST frame
    xSemaphoreGive(mlx_usbd_capture_ready);

    mlx_usbd_task_handle = xTaskCreateStatic(mlx_usbd_task, "mlx_usbd_task", 4096, NULL, tskIDLE_PRIORITY + 1, NULL, NULL);
}

void mlx_usbd_transmit_frame(float *frame_data, size_t frame_size) {
    // Transmit the frame data over USB CDC
    // Example: usbd_cdc_write(frame_data, frame_size * sizeof(float));
    uint32_t total_sent = 0;
    uint32_t to_send = IMAGE_SIZE;

    printf("Starting transmission of %d bytes...\n", IMAGE_SIZE);

    while (to_send > 0) {
        // CherryUSB handles the fragmented packets under the hood
        // We call the write function and it returns when the transfer is queued
        int ret = usbd_ep_start_write(busid, CDC_IN_EP, &image_buffer[total_sent], to_send);

        if (ret == 0) {
            // In a real high-speed scenario, you would wait for a "Transfer Complete" callback
            // For simplicity here, we poll or use a notification.
            total_sent = IMAGE_SIZE;
            to_send = 0;
        }
    }
    printf("Transmission Complete.\n");
}

void mlx_usbd_task(void *param) {
    while (1) {
        // 1. Wait for a frame to be ready
        if (xSemaphoreTake(mlx_usbd_tx_ready, portMAX_DELAY) == pdTRUE) {
            printf("[USB] Sending buffer %d...\n", 0);

            // 2. Transmit the buffer found at read_index
            // Note: This function blocks until queued, or use a callback mechanism
            uint32_t sent = 0;
            while (sent < IMAGE_SIZE) {
                usbd_ep_start_write(CONFIG_USB_DWC2_PORT, CDC_IN_EP, &mlx_usbd_image_buffer[read_index][sent], IMAGE_SIZE - sent);
                // In a real high-speed app, you'd wait for a "Transfer Complete" event here
                // For now, we assume immediate queueing or small blocking
                sent += IMAGE_SIZE;
            }

            // 3. Tell the Camera task we are done sending
            // "I have finished reading buffer X, you can write to it again."
            xSemaphoreGive(mlx_usbd_capture_ready);

            // // Trigger a transmission every 2 seconds
            // send_image_buffer();
            // vTaskDelay(pdMS_TO_TICKS(2000));
        }
    }
}
