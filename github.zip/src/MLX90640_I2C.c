#include <MLX90640_I2C.h>

// i2c_master_bus_handle_t i2c_bus_handle;
// i2c_master_dev_handle_t i2c_handle;

#include "mlx_hal.h"

int MLX90640_I2CProbe(i2c_master_bus_handle_t *bus_handle) {
    if (i2c_master_probe(*bus_handle, 0x33, 1000) == ESP_OK) {
        return 0;
    }
    DBGLOG("DEVICE NOT FOUND");
    return -1;
}

void MLX90640_I2CInit(i2c_master_bus_handle_t *bus_handle, i2c_master_dev_handle_t *dev_handle) {
    i2c_master_bus_config_t bus_config = {
        .i2c_port = CONFIG_I2C_NUM,
        .sda_io_num = CONFIG_I2C_SDA,
        .scl_io_num = CONFIG_I2C_SCL,
        .clk_source = I2C_CLK_SRC_DEFAULT,
        .glitch_ignore_cnt = 7,
        .flags.enable_internal_pullup = true,
    };
    ESP_ERROR_CHECK(i2c_new_master_bus(&bus_config, bus_handle));

    i2c_device_config_t dev_config = {
        .dev_addr_length = I2C_ADDR_BIT_LEN_7,
        .device_address = CONFIG_I2C_DEV_ADDR,
        .scl_speed_hz = CONFIG_I2C_FRQ,
        .flags.disable_ack_check = 0,
    };
    ESP_ERROR_CHECK(i2c_master_bus_add_device(*bus_handle, &dev_config, dev_handle));
}
int MLX90640_I2CStartTransmission(mlx_t mlxh, uint8_t mode) {
    uint8_t sa = (CONFIG_I2C_DEV_ADDR << 1) | mode;
    if (i2c_master_transmit(mlxh->dev, &sa, 1, CONFIG_I2C_TIMEOUT_MS / portTICK_PERIOD_MS) != ESP_OK) {
        DBGLOG("I2CWrite() RET -1");
        return -1;
    }
    return 0;
}
int MLX90640_I2CGeneralReset() {
    return 0;
}
int MLX90640_I2CRead(mlx_t mlxh, uint16_t startAddress, uint16_t nMemAddressRead, uint16_t *data) {
    // DBGLOG("I2CRead() A");
    uint8_t cmd[2];
    while (nMemAddressRead > 0) {
        // DBGLOG("I2CRead() B");
        uint16_t toRead16 = MIN(nMemAddressRead, (uint16_t)(CONFIG_I2C_MAX_BUFFER_SIZE / 2));

        cmd[0] = startAddress >> 8;
        cmd[1] = startAddress & 0x00FF;
        // Serial.printf("Reading %d words\n", toRead16);
        if (i2c_master_transmit_receive(mlxh->dev, cmd, 2, (uint8_t *)data, toRead16 * 2, CONFIG_I2C_TIMEOUT_MS / portTICK_PERIOD_MS) != ESP_OK) {
            DBGLOG("I2CRead() RET -1");
            return -1;
        }
        // we now have to swap every two bytes
        for (int i = 0; i < toRead16; i++) {
            data[i] = __builtin_bswap16(data[i]);
        }
        // DBGLOG(
        //     "\tI2CRead() READ 0x%04x FROM nMAR 0x%02x", *data,
        //     nMemAddressRead
        // );
        // advance buffer
        data += toRead16;
        // advance address
        startAddress += toRead16;
        // reduce remaining to read
        nMemAddressRead -= toRead16;

        // if (!i2c_dev->write_then_read(
        //         cmd, 2, (uint8_t *)data, toRead16 * 2, false
        //     )) {
        //     return -1;
        // }
    }
    // DBGLOG("I2CRead() C");
    return 0;
}
int MLX90640_I2CWrite(mlx_t mlxh, uint16_t writeAddress, uint16_t data) {
    uint8_t  cmd[4];
    uint8_t  readbuf[2] = {0x00, 0x00};
    uint16_t dataCheck = 0x0000;

    cmd[0] = writeAddress >> 8;
    cmd[1] = writeAddress & 0x00FF;
    cmd[2] = data >> 8;
    cmd[3] = data & 0x00FF;

    // if (i2c_master_transmit_receive(
    if (i2c_master_transmit(mlxh->dev, cmd, 4, CONFIG_I2C_TIMEOUT_MS / portTICK_PERIOD_MS) != ESP_OK) {
        DBGLOG("I2CWrite() RET -1");
        return -1;
    }

    if (i2c_master_transmit_receive(mlxh->dev, cmd, 2, readbuf, 2, CONFIG_I2C_TIMEOUT_MS / portTICK_PERIOD_MS) != ESP_OK) {
        DBGLOG("I2CWrite() RET -2. CHECK FAILED.");
        return -2;
    }
    dataCheck = readbuf[1] | (readbuf[0] << 8);

    vTaskDelay(1 / portTICK_PERIOD_MS);

    // check echo
    if (dataCheck != data) {
        DBGLOG("I2CWrite() RET -2. 0x%04x != 0x%04x", dataCheck, data);
        return -2;
    }
    // OK!
    // DBGLOG("I2CWrite() RET OK : 0x%04x == 0x%04x", dataCheck, data);
    return 0;
}
int MLX90640_I2CReadTest(mlx_t mlxh, uint8_t *data, uint16_t reg_addr) {
    uint8_t cmd[2] = {reg_addr >> 8, reg_addr & 0x00FF};
    // uint8_t cmd[2] = {reg_addr & 0x00FF, reg_addr >> 8};

    // MLX90640_I2CStartTransmission(dev_handle, MLX90640_I2C_MODE_W);
    if (i2c_master_transmit(mlxh->dev, cmd, 2, CONFIG_I2C_TIMEOUT_MS / portTICK_PERIOD_MS) != ESP_OK) {
        DBGLOG("i2c_master_transmit() RET -1");
        return -1;
    }
    // MLX90640_I2CStartTransmission(dev_handle, MLX90640_I2C_MODE_R);
    if (i2c_master_receive(mlxh->dev, data, 2, CONFIG_I2C_TIMEOUT_MS / portTICK_PERIOD_MS) != ESP_OK) {
        DBGLOG("i2c_master_receive() RET -1");
        return -1;
    }
    return 0;
}
void MLX90640_I2CFreqSet(int freq) {
}