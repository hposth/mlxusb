#include "mlx_i2c.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"
#include "driver/i2c.h"

// --- Configuration ---
#define I2C_PORT 0
#define I2C_FREQ_HZ 800000 // 800kHz (Reliable max for many MLX sensors)
#define I2C_SDA_PIN 1
#define I2C_SCL_PIN 2
#define MLX_ADDR 0x33

// --- Synchronization ---
static SemaphoreHandle_t  sem_start_transfer;   // Signal from Main -> I2C Task
static SemaphoreHandle_t  sem_transfer_done;    // Signal from I2C Task -> Main
static volatile uint16_t *target_buffer = NULL; // Pointer exchange variable

// --- I2C Worker Task ---
// This task sits blocked until ordered to fetch data.
// It runs at high priority to keep the I2C FIFO full/empty.
void i2c_worker_task(void *arg) {
    // 1. Setup I2C Config (Legacy Driver is robust for this specific restart sequence)
    i2c_config_t conf = {
        .mode = I2C_MODE_MASTER,
        .sda_io_num = I2C_SDA_PIN,
        .scl_io_num = I2C_SCL_PIN,
        .sda_pullup_en = GPIO_PULLUP_ENABLE,
        .scl_pullup_en = GPIO_PULLUP_ENABLE,
        .master.clk_speed = I2C_FREQ_HZ,
    };
    i2c_param_config(I2C_PORT, &conf);
    // Install driver with large RX buffer to allow interrupt handler to work efficiently
    i2c_driver_install(I2C_PORT, conf.mode, 0, 0, 0);

    while (1) {
        // A. Wait for request from Main Task
        xSemaphoreTake(sem_start_transfer, portMAX_DELAY);

        // B. Execute the Transaction (Blocking context, but in parallel with Main Task)
        i2c_cmd_handle_t cmd = i2c_cmd_link_create();

        // Step 1: Write Address (0x0400)
        i2c_master_start(cmd);
        i2c_master_write_byte(cmd, (MLX_ADDR << 1) | I2C_MASTER_WRITE, true);
        i2c_master_write_byte(cmd, 0x04, true);
        i2c_master_write_byte(cmd, 0x00, true);

        // Step 2: Restart and Read Bulk Data (832 words = 1664 bytes)
        i2c_master_start(cmd);
        i2c_master_write_byte(cmd, (MLX_ADDR << 1) | I2C_MASTER_READ, true);
        i2c_master_read(cmd, (uint8_t *)target_buffer, 1664, I2C_MASTER_LAST_NACK);
        i2c_master_stop(cmd);

        // Execute I2C
        // The timeout is critical; if I2C hangs, we don't want to lock forever.
        esp_err_t ret = i2c_master_cmd_begin(I2C_PORT, cmd, pdMS_TO_TICKS(50));
        i2c_cmd_link_delete(cmd);

        // Step 3: Read Status Register (0x8000) for Subpage ID
        // (Simplified: assuming success, real code should check 'ret')
        if (ret == ESP_OK) {
            cmd = i2c_cmd_link_create();
            i2c_master_start(cmd);
            i2c_master_write_byte(cmd, (MLX_ADDR << 1) | I2C_MASTER_WRITE, true);
            i2c_master_write_byte(cmd, 0x80, true);
            i2c_master_write_byte(cmd, 0x00, true);
            i2c_master_start(cmd);
            i2c_master_write_byte(cmd, (MLX_ADDR << 1) | I2C_MASTER_READ, true);
            uint8_t status[2];
            i2c_master_read(cmd, status, 2, I2C_MASTER_LAST_NACK);
            i2c_master_stop(cmd);
            i2c_master_cmd_begin(I2C_PORT, cmd, pdMS_TO_TICKS(10));
            i2c_cmd_link_delete(cmd);

            // Append status to end of buffer
            target_buffer[833] = (status[0] << 8) | status[1];
        }

        // C. Signal Completion
        xSemaphoreGive(sem_transfer_done);
    }
}

// --- Public API ---

void mlx_async_init() {
    sem_start_transfer = xSemaphoreCreateBinary();
    sem_transfer_done = xSemaphoreCreateBinary();

    // Create I2C worker on Core 0 (System Core)
    // We leave Core 1 free for the Heavy Math/USB task
    xTaskCreatePinnedToCore(i2c_worker_task, "i2c_worker", 4096, NULL, 15, NULL, 0);
}

// Non-blocking call to start a frame fetch
void mlx_async_fetch_start(uint16_t *buffer) {
    target_buffer = buffer;

    // Check if we are inside an ISR
    if (xPortInIsrContext()) {
        BaseType_t xHigherPriorityTaskWoken = pdFALSE;
        xSemaphoreGiveFromISR(sem_start_transfer, &xHigherPriorityTaskWoken);

        // Force context switch if necessary
        if (xHigherPriorityTaskWoken) {
            portYIELD_FROM_ISR();
        }
    } else {
        // Normal Task Context
        xSemaphoreGive(sem_start_transfer);
    }
}

// Blocking wait for the fetch to complete
void mlx_async_fetch_wait() {
    xSemaphoreTake(sem_transfer_done, portMAX_DELAY);
}