#ifdef CONFIG_MLX_CDC_VCP

#include "usbd_core.h"
#include "usbd_cdc.h"
#include "usbd_cdc_acm.h"
#include "mlx_usb_cdc.h"
#include "mlx_usb_config.h"
#include "soc/reg_base.h"
#include "soc/usb_wrap_reg.h"
#include "hal/usb_serial_jtag_ll.h"
#include "soc/usb_wrap_struct.h"
#include <usb_def.h>
#include <esp_attr.h>
#include <esp_log.h>

#include "driver/periph_ctrl.h"
#include "esp_private/usb_phy.h" // Or "soc/usb_periph.h" depending on IDF version
#include "driver/gpio.h"

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include <soc/soc.h>

#include "hal/usb_dwc_ll.h"     // Low-level DWC3/DWC2 definitions
#include "soc/usb_dwc_struct.h" // The actual register structures
#include "driver/periph_ctrl.h" // For periph_module_enable

#include "esp_intr_alloc.h"

// 1. Declare the ISR provided by the CherryUSB driver
extern void USBD_IRQHandler(uint8_t busid);

// Ring buffer for USB TX
// DRAM_ATTR USB_NOCACHE_RAM_SECTION USB_MEM_ALIGNX uint8_t mlx_write_buffer[CDC_WRITE_BUF_SIZE];
USB_NOCACHE_RAM_SECTION USB_MEM_ALIGNX uint8_t mlx_write_buffer[2048];

// Ring buffer for USB RX
// DRAM_ATTR USB_NOCACHE_RAM_SECTION USB_MEM_ALIGNX uint8_t mlx_read_buffer[CDC_READ_BUF_SIZE];
USB_NOCACHE_RAM_SECTION USB_MEM_ALIGNX uint8_t mlx_read_buffer[2048];

volatile bool ep_tx_busy_flag = false;

int usbd_printf(const char *format, ...) {
    va_list args;
    va_start(args, format);
    // int ret = vprintf(format, args);
    int ret = vsnprintf((char *)mlx_write_buffer, CDC_WRITE_BUF_SIZE, format, args);
    // usbd_cdc_acm_bulk_out(CONFIG_USB_DWC2_PORT, CDC_OUT_EP, 0);                           // Re-arm OUT endpoint

    // printf("[usbd_printf] Calling usbd_ep_start_write()...\n");
    ret = usbd_ep_start_write(CONFIG_USB_DWC2_PORT, CDC_IN_EP, (uint8_t *)mlx_write_buffer, 0); // Ensure IN endpoint is ready
    // printf("[usbd_printf] usbd_ep_start_write() returned %d\n", ret);
    va_end(args);
    return ret;
}

void usbd_cdc_acm_bulk_out(uint8_t busid, uint8_t ep, uint32_t nbytes) {
    USB_LOG_RAW("actual out len:%d\r\n", (unsigned int)nbytes);
    for (int i = 0; i < 100; i++) {
        printf("%02x ", mlx_read_buffer[i]);
    }
    printf("\r\n");
    /* setup next out ep read transfer */
    usbd_ep_start_read(busid, CDC_OUT_EP, mlx_read_buffer, 2048);
}

void usbd_cdc_acm_bulk_in(uint8_t busid, uint8_t ep, uint32_t nbytes) {
    USB_LOG_RAW("actual in len:%d\r\n", (unsigned int)nbytes);

    if ((nbytes % usbd_get_ep_mps(busid, ep)) == 0 && nbytes) {
        /* send zlp */
        usbd_ep_start_write(busid, CDC_IN_EP, NULL, 0);
    } else {
        ep_tx_busy_flag = false;
    }
}

static struct usbd_endpoint cdc_out_ep = {.ep_addr = CDC_OUT_EP, .ep_cb = usbd_cdc_acm_bulk_out};

static struct usbd_endpoint cdc_in_ep = {.ep_addr = CDC_IN_EP, .ep_cb = usbd_cdc_acm_bulk_in};

static struct usbd_interface intf0;
static struct usbd_interface intf1;

/**
 * // USB Device Descriptor
 * const uint8_t device_descriptor[] = {USB_DEVICE_DESCRIPTOR_INIT(USB_2_0, 0x00, 0x00, 0x00, 0xFFFF, 0xFFFF, 0x0100, 0x01)};
 *
 * #define USB_CONFIG_SIZE_TOTAL (USB_CONFIG_DESCRIPTOR_SIZE + USB_INTERFACE_DESCRIPTOR_SIZE + USB_ENDPOINT_DESCRIPTOR_SIZE + USB_ENDPOINT_DESCRIPTOR_SIZE)
 *
 *
 * // USB Configuration Descriptor
 * const uint8_t config_descriptor[] = {
 *         USB_CONFIG_DESCRIPTOR_INIT(USB_CONFIG_SIZE_TOTAL, 1, 1, CONFIG_USB_POWER_SOURCE, 100), // Configuration
 *         USB_INTERFACE_DESCRIPTOR_INIT(0, 0, 2, 0xFF, 0x00, 0x00, 0),                           // Interface
 *         USB_ENDPOINT_DESCRIPTOR_INIT(CDC_IN_EP, USB_ENDPOINT_TYPE_BULK, PACKET_SIZE, 0x00),    // Endpoint IN
 *         USB_ENDPOINT_DESCRIPTOR_INIT(CDC_OUT_EP, USB_ENDPOINT_TYPE_BULK, PACKET_SIZE, 0x00)    // Endpoint OUT
 *     };
 *
 *  // String Descriptors
 * const char *string_descriptors[] = {
 *     (const char[]){0x09, 0x04}, // Language ID
 *     "Manufacturer", // Manufacturer
 *     "ESP32-S3 Image Link", // Product
 *     "123456", // Serial Number
 * };
 **/

#define PACKET_SIZE 64 // Max packet size for USB Full Speed

// Device Descriptor
static const uint8_t device_descriptor[] = {USB_DEVICE_DESCRIPTOR_INIT(USB_2_0, 0xEF, 0x02, 0x01, 0xFFFF, 0xFFFF, 0x0100, 0x01)};

// Config Descriptor
// Length = Config(9) + IAD(8) + Interface0(9) + CDC Header(5) + ACM(4) + Union(5) + EP_INT(7) + Interface1(9) + EP_OUT(7) + EP_IN(7)
// Simplified here for basic bulk, but usually CDC needs the full set.
// We use your simplified definition for now:
#define USB_CONFIG_SIZE_TOTAL (USB_CONFIG_DESCRIPTOR_SIZE + USB_INTERFACE_DESCRIPTOR_SIZE + USB_ENDPOINT_DESCRIPTOR_SIZE + USB_ENDPOINT_DESCRIPTOR_SIZE)

static const uint8_t config_descriptor[] = {USB_CONFIG_DESCRIPTOR_INIT(USB_CONFIG_SIZE_TOTAL, 1, 1, USB_CONFIG_BUS_POWERED, 100),
                                            USB_INTERFACE_DESCRIPTOR_INIT(0, 0, 2, 0xFF, 0x00, 0x00, 0),
                                            USB_ENDPOINT_DESCRIPTOR_INIT(CDC_OUT_EP, USB_ENDPOINT_TYPE_BULK, 0x40, 0x00),
                                            USB_ENDPOINT_DESCRIPTOR_INIT(CDC_IN_EP, USB_ENDPOINT_TYPE_BULK, 0x40, 0x00)};

static const uint8_t device_quality_descriptor[] = {
    ///////////////////////////////////////
    /// device qualifier descriptor
    ///////////////////////////////////////
    0x0a,
    USB_DESCRIPTOR_TYPE_DEVICE_QUALIFIER,
    0x00,
    0x02,
    0x00,
    0x00,
    0x00,
    0x40,
    0x00,
    0x00,
};

// Strings (Index 0 is LangID, 1=Mfg, 2=Prod, 3=Serial)
static const char *string_descriptors[] = {
    (const char[]){0x09, 0x04}, // 0: LangID (0x0409)
    "Posthumus", // 1: Manufacturer
    "MLX Thermal Image Link", // 2: Product
    "123456", // 3: Serial
};

// --- 2. Callback Wrappers (The "Glue" Logic) ---

static const uint8_t *get_device_descriptor(uint8_t speed) {
    return device_descriptor;
}

static const uint8_t *get_config_descriptor(uint8_t speed) {
    return config_descriptor;
}

static const uint8_t *get_device_quality_descriptor(uint8_t speed) {
    return device_quality_descriptor;
}

static const char *get_string_descriptor(uint8_t speed, uint8_t index) {
    static uint8_t str_buf[128];

    // Case 0: Language ID
    if (index == 0) {
        str_buf[0] = 4;
        str_buf[1] = 0x03;
        str_buf[2] = 0x09;
        str_buf[3] = 0x04;
        return (const char *)str_buf;
    }

    if (index >= (sizeof(string_descriptors) / sizeof(char *))) {
        return NULL;
    }

    const char *str = string_descriptors[index];
    int         len = strlen(str);
    if (len > 63)
        len = 63;

    str_buf[0] = len * 2 + 2;
    str_buf[1] = 0x03;

    for (int i = 0; i < len; i++) {
        str_buf[2 + i * 2] = str[i];
        str_buf[2 + i * 2 + 1] = 0x00;
    }

    return (const char *)str_buf;
}

// --- 3. The Struct Definition ---

// Note: singular 'struct usb_descriptor' using callbacks
const struct usb_descriptor cdc_descriptor_callbacks = {
    .device_descriptor_callback = get_device_descriptor,
    .config_descriptor_callback = get_config_descriptor,
    .device_quality_descriptor_callback = get_device_quality_descriptor,
    // .other_speed_descriptor_callback = NULL,
    .string_descriptor_callback = get_string_descriptor,
    // .msosv1_descriptor = NULL,
    // .msosv2_descriptor = NULL,
    // .webusb_url_descriptor = NULL,
    // .bos_descriptor = NULL,
};

// --- 4. Initialization ---
// static usb_phy_handle_t phy_handle = NULL;

// #define LED_PIN GPIO_NUM_47
// void usb_init_phy() {
//     // 1. Configure the Internal USB PHY

//     usb_phy_config_t phy_conf = {
//         .controller = USB_PHY_CTRL_OTG,  // Select the OTG Controller (not JTAG)
//         .target = USB_PHY_TARGET_INT,    // Use Internal PHY (GPIO 19/20)
//         .otg_mode = USB_OTG_MODE_DEVICE, // Device Mode
//     };

//     gpio_set_direction(LED_PIN, GPIO_MODE_OUTPUT);

//     // Blink 5 times FAST to signal "App Started"
//     for (int i = 0; i < 5; i++) {
//         gpio_set_level(LED_PIN, 1);
//         vTaskDelay(pdMS_TO_TICKS(100));
//         gpio_set_level(LED_PIN, 0);
//         vTaskDelay(pdMS_TO_TICKS(100));
//     }

//     // 2. Initialize the PHY
//     // This handles the Clock Enable, GPIO setup, and JTAG/OTG Muxing automatically.
//     esp_err_t err = usb_new_phy(&phy_conf, &phy_handle);
//     if (err == ESP_ERR_INVALID_STATE) {
//         // This means it's ALREADY initialized.
//         // If the JTAG console is truly off, this shouldn't happen.
//         // But if it does, we might be able to proceed anyway if we are lucky.
//         ESP_LOGW("USB", "[W] USB PHY was already initialized!\n");
//     } else if (err != ESP_OK) {
//         ESP_LOGE("USB", "[E] USB PHY Init Failed: %s\n", esp_err_to_name(err));
//         // return;
//     }

//     gpio_set_level(LED_PIN, 1);
//     // // 1. Enable the USB OTG Peripheral Clock
//     // // Without this, all register reads (like GRXFSIZ) return 0!
//     // periph_module_reset(PERIPH_USB_MODULE);
//     // periph_module_enable(PERIPH_USB_MODULE);

//     // // 2. (Optional but recommended) Force GPIOs 19/20 to USB Mode
//     // // This ensures they aren't stuck in JTAG/UART mode
//     // gpio_set_direction(GPIO_NUM_19, GPIO_MODE_INPUT_OUTPUT);
//     // gpio_set_direction(GPIO_NUM_20, GPIO_MODE_INPUT_OUTPUT);

//     // // Connect the Internal PHY (Usually handled by hardware, but good to be safe)
//     // // On ESP32-S3, enabling the PERIPH_USB_MODULE usually handles this.
// }

static void usbd_event_handler(uint8_t busid, uint8_t event) {
    switch (event) {
    case USBD_EVENT_RESET:
        uprintf("USB Reset!\n");
        break;
    case USBD_EVENT_CONNECTED:
        uprintf("USB Connected!\n");
        break;
    case USBD_EVENT_DISCONNECTED:
        uprintf("USB Disconnected!\n");
        break;
    case USBD_EVENT_RESUME:
        uprintf("USB Resumed!\n");
        break;
    case USBD_EVENT_SUSPEND:
        uprintf("USB Suspended!\n");
        break;
    case USBD_EVENT_CONFIGURED:
        ep_tx_busy_flag = false;
        /* setup first out ep read transfer */
        usbd_ep_start_read(busid, CDC_OUT_EP, mlx_read_buffer, 2048);
        uprintf("USB Configured!\n");
        break;
    case USBD_EVENT_SET_REMOTE_WAKEUP:
        uprintf("USB Set Remote Wakeup!\n");
        break;
    case USBD_EVENT_CLR_REMOTE_WAKEUP:
        uprintf("USB Clear Remote Wakeup!\n");
        break;
    case USBD_EVENT_INIT:
        uprintf("USB Initialized!\n");
        break;
    case USBD_EVENT_ERROR:
        uprintf("USB Error!\n");
        break;

    default:
        uprintf("USB Unknown Event: %d\n", event);
        break;
    }
}

volatile uint8_t dtr_enable = 0;

void usbd_cdc_acm_set_dtr(uint8_t busid, uint8_t intf, bool dtr) {
    if (dtr) {
        dtr_enable = 1;
    } else {
        dtr_enable = 0;
    }
}

void cdc_acm_data_send_with_dtr_test(uint8_t busid) {
    if (dtr_enable) {
        ep_tx_busy_flag = true;
        usbd_ep_start_write(busid, CDC_IN_EP, mlx_write_buffer, 2048);
        while (ep_tx_busy_flag) {
        }
    }
}

esp_err_t usb_init_cdc() {
    // 1. Manually flip the Mux to OTG (The "Force Hijack")
    // This ensures that even if the system tried to claim it, we take it back.
    // SET_PERI_REG_MASK(USB_WRAP_OTG_CONF_REG, USB_WRAP_USB_PAD_ENABLE);
    // CLEAR_PERI_REG_MASK(USB_WRAP_OTG_CONF_REG, USB_WRAP_PULLUP_VALUE); // Let DWC2 handle pullups

    // gpio_sleep_sel_dis(GPIO_NUM_19);
    // gpio_sleep_sel_dis(GPIO_NUM_20);

    // usb_init_phy();
    // 1. Force Enable the Peripheral Clock
    // periph_module_reset(PERIPH_USB_MODULE);
    // periph_module_enable(PERIPH_USB_MODULE);

    // 2. Initialize the Internal PHY
    // static usb_phy_handle_t phy_hdl;
    // usb_phy_config_t        phy_conf = {
    //            .controller = USB_PHY_CTRL_OTG,
    //            .target = USB_PHY_TARGET_INT,
    //            .otg_mode = USB_OTG_MODE_DEVICE,
    // };

    // printf("[I] USB calling usb_new_phy.\n");
    // 1. Enable USB Peripheral Clock
    // periph_module_enable(PERIPH_USB_MODULE);
    // periph_module_reset(PERIPH_USB_MODULE);

    // 2. Setup the Wrapper (This is the "S3 Secret")
    // This tells the S3: "Don't use JTAG, give the pins to the OTG controller."
    // USB_WRAP.otg_conf.pad_enable = 1;
    // USB_WRAP.otg_conf.phy_sel = 0; // Use internal PHY

    // USB_WRAP.otg_conf.pad_enable = 1;
    // usb_serial_jtag_ll_phy_enable_external(false);

    // // 3. Initialize the PHY
    // static usb_phy_handle_t phy_hdl;
    // usb_phy_config_t        phy_conf = {
    //            .controller = USB_PHY_CTRL_OTG,
    //            .target = USB_PHY_TARGET_INT,
    //            .otg_mode = USB_OTG_MODE_DEVICE,
    // };
    // esp_err_t ret = usb_new_phy(&phy_conf, &phy_hdl);

    // esp_err_t ret = usb_new_phy(&phy_conf, &phy_hdl);
    esp_err_t ret = ESP_OK;
    // printf("[I] USB returned from usb_new_phy with ret=%d.\n", (int)ret);
    // if (ret != ESP_OK) {
    //     printf("[E] PHY Init Failed: %s. Is JTAG Console still on?\n", esp_err_to_name(ret));
    //     return ret;
    // }

    const uint8_t data[10] = {0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x30};

    memcpy(&mlx_write_buffer[0], data, 10);
    memset(&mlx_write_buffer[10], 'a', 2038);

    printf("[I] USB passed error check with ret=%s.\n Continuing to usbd_desc_register.\n", esp_err_to_name(ret));

    usbd_desc_register(CONFIG_USB_DWC2_PORT, &cdc_descriptor_callbacks);

    // usbd_desc_register(CONFIG_USB_DWC2_PORT, device_descriptor);
    // usbd_desc_register(CONFIG_USB_DWC2_PORT, config_descriptor);
    // usbd_desc_register(CONFIG_USB_DWC2_PORT, string_descriptors);
    printf("[I] USB registered descriptors. Continuing to add interfaces and endpoints.\n");
    usbd_add_interface(CONFIG_USB_DWC2_PORT, usbd_cdc_acm_init_intf(CONFIG_USB_DWC2_PORT, &intf0));
    usbd_add_interface(CONFIG_USB_DWC2_PORT, usbd_cdc_acm_init_intf(CONFIG_USB_DWC2_PORT, &intf1));
    printf("[I] USB added interfaces. Continuing to add endpoints.\n");
    usbd_add_endpoint(CONFIG_USB_DWC2_PORT, &cdc_out_ep);
    usbd_add_endpoint(CONFIG_USB_DWC2_PORT, &cdc_in_ep);
    // int ret = usbd_initialize(CONFIG_USB_DWC2_PORT, DR_REG_USB_WRAP_BASE, NULL);
    printf("[I] USB added endpoints. Continuing to usbd_initialize.\n");

    // Initialize with the custom parameters
    // ret = (usbd_initialize(0, 0x60040000, &s3_fifo_params) == 0) ? ESP_OK : ESP_FAIL;

    printf("[I] USB calling usbd_initialize on port %d.\n", CONFIG_USB_DWC2_PORT);
    // if (usb_device_is_configured(CONFIG_USB_DWC2_PORT)) {
    //     printf("\tusb_device_is_configured() returned true.\n");
    // } else {
    //     printf("\tusb_device_is_configured() returned false.\n");
    // }
    // ret = (usbd_initialize(CONFIG_USB_DWC2_PORT, ESP_USB_FS0_BASE, usbd_event_handler) == 0) ? ESP_OK : ESP_FAIL;
    // ret = (esp_err_t)
    usbd_initialize(CONFIG_USB_DWC2_PORT, ESP_USB_FS0_BASE, usbd_event_handler);
    printf("[I] USB finished usbd_initialize with ret=%d.\n", (int)ret);
    // if (usb_device_is_configured(CONFIG_USB_DWC2_PORT)) {
    //     printf("\tusb_device_is_configured() returned true.\n");
    // } else {
    //     printf("\tusb_device_is_configured() returned false.\n");
    // }

    return ret;
    // usbd_initialize(CONFIG_USB_DWC2_PORT, 0, NULL);
}

// Non-blocking send
void usb_send_frame(uint8_t *data, uint32_t len) {
    if (usb_device_is_configured(CONFIG_USB_DWC2_PORT)) {
        usbd_ep_start_write(CONFIG_USB_DWC2_PORT, CDC_IN_EP, data, len);
    }
}

#endif // !CONFIG_MLX_CDC_VCP