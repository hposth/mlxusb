#include "mlx_hal.h"

mlx_t mlx_create(i2c_master_bus_handle_t bus, i2c_master_dev_handle_t dev) {
    DBGLOG("mlx_create [0]");
    mlx_t mlx = malloc(sizeof(struct mlx_dev_t));
    if (!mlx) {
        DBGLOG("mlx_create [1] ERR");
        return NULL; // handle error in caller
    }
    DBGLOG("mlx_create [1] OK");
    mlx->bus = bus;
    DBGLOG("mlx_create [2]");
    mlx->dev = dev;
    DBGLOG("mlx_create [3] RET OK");
    return mlx;
}

// int mlx_hal_read(mlx_t mlxh, uint16_t reg, uint16_t nbytes, uint16_t *data) {
//     uint8_t  sa;
//     int      cnt        = 0;
//     int      i          = 0;
//     uint8_t  command[2] = {0, 0};
//     uint8_t *i2cData;
//     int      i2cData_len = 1664;
//     i2cData              = malloc(i2cData_len);
//     uint16_t *p;

//     p          = data;
//     sa         = (CONFIG_I2C_DEV_ADDR << 1);
//     command[0] = reg >> 8;
//     command[1] = reg & 0x00FF;

//     i2c_cmd_handle_t cmd = i2c_cmd_link_create();
//     i2c_master_start(cmd);
//     // slave address
//     i2c_master_write_byte(cmd, sa | I2C_MASTER_WRITE, 0x1);
//     // device registers to be read
//     i2c_master_write(cmd, command, 2, 0x1);

//     i2c_master_start(cmd);
//     // slave address before streaming
//     i2c_master_write_byte(cmd, sa | I2C_MASTER_READ, 0x1);
//     // read all bytes -1 terminated with ACK
//     i2c_master_read(cmd, i2cData, 2 * nbytes - 1, 0x0);
//     // read final byte termated with NACK
//     i2c_master_read_byte(cmd, i2cData + (2 * nbytes - 1), 0x1);
//     i2c_master_stop(cmd);

//     esp_err_t ret = i2c_master_cmd_begin(
//         I2C_NUM_0, cmd, CONFIG_I2C_TIMEOUT_MS / portTICK_PERIOD_MS
//     );
//     i2c_cmd_link_delete(cmd);

//     for (cnt = 0; cnt < nbytes; cnt++) {
//         i    = cnt << 1;
//         *p++ = (uint16_t)i2cData[i] * 256 + (uint16_t)i2cData[i + 1];
//     }

//     free(i2cData);

//     if (ret != ESP_OK) {
//         DBGLOG("MLX_HAL : I2C READ ERROR %i", ret);
//     }
//     return ret;
//     return 0;
// }
// int mlx_hal_write(mlx_t mlxh, uint16_t reg, uint16_t data) {
//     uint8_t         sa;
//     uint8_t         command[4] = {0, 0, 0, 0};
//     static uint16_t dataCheck;

//     sa         = (CONFIG_I2C_DEV_ADDR << 1);
//     command[0] = reg >> 8;
//     command[1] = reg & 0x00FF;
//     command[2] = data >> 8;
//     command[3] = data & 0x00FF;

//     i2c_cmd_handle_t cmd = i2c_cmd_link_create();
//     i2c_master_start(cmd);
//     i2c_master_write_byte(cmd, sa | I2C_MASTER_WRITE, 0x1);
//     i2c_master_write(cmd, command, 4, 0x1);
//     i2c_master_stop(cmd);

//     esp_err_t ret = i2c_master_cmd_begin(
//         I2C_NUM_0, cmd, CONFIG_I2C_TIMEOUT_MS / portTICK_PERIOD_MS
//     );
//     i2c_cmd_link_delete(cmd);

//     if (ret != ESP_OK) {
//         DBGLOG("MLX_HAL : I2C WRITE ERROR");
//     }

//     mlx_hal_read(mlxh, reg, 1, &dataCheck);
//     if (dataCheck != data) {
//         return -2;
//     }

//     return 0;
// }