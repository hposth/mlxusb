#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>

// #include "MLX90640_API.h"
// #include "MLX90640_I2C.h"
#include "mlx.h"
#include "mlx_defs.h"
// #include "mlx_usbd.h"

#include <freertos/FreeRTOS.h>
#include <freertos/queue.h>
#include <freertos/task.h>
#include "esp_log.h"

// #define PRINT_ASCIIART
// #define PRINT_TEMPERATURES
#define PRINT_ENCODED

mlx_t _mlx;

float frame[32 * 24];

void MLX90640_Test() {
    uint16_t conf_reg[4] = {0xCCCC, 0xCCCC, 0xCCCC, 0xCCCC};
    uint16_t dev_sn[3] = {0xCCCC, 0xCCCC, 0xCCCC};
    MLX90640_I2CRead(_mlx, MLX90640_DEVICE_IDENT_REG, 3, dev_sn);
    uint16_t *_p = (uint16_t *)dev_sn;
    MLX90640_I2CRead(_mlx, MLX90640_CTRL_REG, 1, (uint16_t *)conf_reg);
    DBGLOG("CONF REG      [CR1:%04x]: 0x%04x", 0x800D, conf_reg[0]);
    MLX90640_I2CRead(_mlx, 0x800E, 1, ((uint16_t *)conf_reg + 1));
    DBGLOG("CONF REG      [CR2:%04x]: 0x%04x", 0x800E, conf_reg[1]);
    MLX90640_I2CRead(_mlx, 0x800F, 1, ((uint16_t *)conf_reg + 2));
    DBGLOG("CONF REG      [IIC:%04x]: 0x%04x", 0x800F, conf_reg[2]);
    MLX90640_I2CRead(_mlx, 0x8010, 1, ((uint16_t *)conf_reg + 3));
    DBGLOG("CONF REG      [ADR:%04x]: 0x%04x", 0x8010, conf_reg[3]);
    MLX90640_I2CRead(_mlx, 0x2407, 3, _p);
    DBGLOG("SERIAL NUMBER [IDx:%04x]: 0x%06x", 0x2407, *_p);
}

void getFrame(mlx_t mlxh) {
    // vTaskDelay(500 / portTICK_PERIOD_MS);
    vTaskDelay(200 / portTICK_PERIOD_MS);
    if (mlx_get_frame(mlxh, frame) != 0) {
        printf("Failed\n");
        return;
    }
    printf("===================================\n");
    printf("Ambient temperature = ");
    printf("%.4f", mlx_get_ta(mlxh, false)); // false = no new frame capture
    printf(" degC\n");
    printf("\n");
    printf("\n");
#ifdef PRINT_TEMPERATURES || PRINT_ASCIIART
    for (uint8_t h = 0; h < 24; h++) {
        for (uint8_t w = 0; w < 32; w++) {
            float t = frame[h * 32 + w];
#ifdef PRINT_TEMPERATURES
// printf(t, 1);
// printf(", ");
#endif
#ifdef PRINT_ASCIIART
            char c = '&';
            if (t < 20)
                c = ' ';
            else if (t < 23)
                c = '.';
            else if (t < 25)
                c = '-';
            else if (t < 27)
                c = '*';
            else if (t < 29)
                c = '+';
            else if (t < 31)
                c = 'x';
            else if (t < 33)
                c = '%';
            else if (t < 35)
                c = '#';
            else if (t < 37)
                c = 'X';
            printf("%c", c);
#endif
        }
        printf("\n");
    }
#endif
#ifdef PRINT_ENCODED
    // uint16_t et = (uint16_t)(t * 10);
    // printf("%04x ", et);
    struct _reent *r = _REENT;
    stdout->_write((const char *)frame, sizeof(frame));
    write();
#endif
}

void app_main(void) {
    esp_log_level_set("*", ESP_LOG_DEBUG);
    // esp_log_level_set("i2c", ESP_LOG_VERBOSE);

    DBGLOG("[app_main() called]");
    mlx_begin(&_mlx);
    DBGLOG("[mlx_begin(&_mlx)] OK");
    DBGLOG("[MLX90640_SetRefreshRate( 0x6 )]"); // 0x6 = 32 Hz
    // MLX90640_Test();
    MLX90640_SetRefreshRate(_mlx, 0x6);
    DBGLOG("[mlx_setRefreshRate()] OK");
    MLX90640_SetResolution(_mlx, 0x0);
    DBGLOG("[mlx_setResolution()] OK");

    MLX90640_SetInterleavedMode(_mlx); // Chess mode is default
    DBGLOG("[mlx_setInterleavedMode()] OK");

    mlx_usbd_init();
    DBGLOG("[mlx_usbd_init()] OK");
    while (true) {
        DBGLOG("[MAIN TASK ALIVE]");
        //     getFrame(_mlx);

        vTaskDelay(3000 / portTICK_PERIOD_MS);
    }
}
