#include "mlx_usb_cdc.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "sdkconfig.h"

// Packet structure:
// Header (2) + Subpage ID (1) + Data (384 * 2) = 771 bytes
#define PACKET_LEN 771

#define CDC_IN_EP 0x81
#define CDC_OUT_EP 0x02
#define CDC_INT_EP 0x83

void send_subpage_over_usb(uint8_t *packet_buffer) {
    printf("[I] mlx_usb_cdc.c : send_subpage_over_usb() called.\n");
    if (usb_device_is_configured(CONFIG_MLX_USB_DWC2_PORTID)) {
        // This must be non-blocking or have a very short timeout
        // CherryUSB 'usbd_ep_start_write' is generally async but check your specific port
        int ret = usbd_ep_start_write(CONFIG_MLX_USB_DWC2_PORTID, CDC_IN_EP, packet_buffer, PACKET_LEN);
        // if (!usbd_ep_start_write(CONFIG_USB_DWC2_PORT, CDC_IN_EP, packet_buffer, PACKET_LEN)) {
        if (ret != 0) {
            printf("[E] usbd_ep_start_write() error: %d.\n", ret);
            vTaskDelay(100 / portTICK_PERIOD_MS);
        }
        // printf("[E] usbd_ep_start_write() wrote: %d bytes.\n", PACKET_LEN);
        vTaskDelay(1000 / portTICK_PERIOD_MS);
    } else {
        printf("[I] mlx_usb_cdc.c : usb_device_is_configured(0) returned false.\n");
        vTaskDelay(1000 / portTICK_PERIOD_MS);
    }
    printf("[I] mlx_usb_cdc.c : send_subpage_over_usb() returning.\n");
}