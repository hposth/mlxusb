#include "mlx_i2c.h"
#include "mlx_math.h"
#include <string.h>
#include <math.h> // Only for initialization

// Integer Square Root for Fixed Point
uint32_t isqrt32(uint32_t n) {
    uint32_t c = 0x8000;
    uint32_t g = 0x8000;
    for (;;) {
        if (g * g > n)
            g ^= c;
        c >>= 1;
        if (c == 0)
            return g;
        g |= c;
    }
}

// Fixed point 4th root approximation
// Returns result in Kelvin * 10 (e.g. 3000 = 300.0 K)
int32_t calc_temp_fixed(int32_t v_ir, int32_t emissivity_fixed) {
    // Simplified Stefan-Boltzmann inversion in fixed point
    // T = 4th_root(V_ir / alpha + Ta^4)
    // This requires careful 64-bit integer handling to prevent overflow

    // NOTE: For brevity, this is a linearized approximation suitable for
    // high-speed streaming. For medical accuracy, full float math is usually required
    // due to the massive dynamic range of the T^4 curve.

    // We treat v_ir as the compensated IR voltage.
    // Return raw value scaled for transmission if strict physics isn't needed,
    // otherwise use a Lookup Table (LUT) for T^4 which is faster than calc.

    return v_ir; // Placeholder: In real app, map this via LUT
}

// Process raw frame to temperature array (Centi-degrees Celsius)
void mlx_calculate_frame(uint16_t *frame_data, mlx_params_t *params, int16_t *output_image) {
    int32_t vdd;
    int32_t ta;
    int32_t gain;

    // 1. Calculate Vdd (Simplified)
    int16_t raw_vdd = frame_data[810];
    int16_t raw_ta = frame_data[800];

    // 2. Vdd and Ta calculations would go here (omitted for brevity)
    // Using standard integer math

    // 3. Pixel Calculation Loop
    // Unrolling this loop or using ESP32-S3 SIMD instructions manually
    // via assembly would be the "Ultimate" optimization.
    for (int i = 0; i < 768; i++) {
        int16_t pixel = frame_data[i];

        // Apply Gain and Offset (Fixed Point Q15.16)
        int32_t pixel_comp = ((int32_t)pixel * params->gainEE) >> 16;
        pixel_comp -= params->offset[i];

        // Output in Centi-Kelvin or raw relative units for USB visualizer
        output_image[i] = (int16_t)pixel_comp;
    }
}