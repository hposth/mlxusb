#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "macro.h"
#include "mlx_i2c.h"
#include "mlx_process.h"
#ifdef CONFIG_MLX_DC_WINUSB2
#include "mlx_usb_vsc.h"
#else // CONFIG_MLX_CDC_VCP || CONFIG_MLX_CDC_WINUSB2
#include "mlx_usb_cdc.h"
#endif
#include "device_cdc_main.h"
#include <esp_private/usb_phy.h>

#define USBD_WINUSB_VERBOSE
#define USBD_BUSID CONFIG_MLX_USB_DWC2_PORTID
#define USBD_BASEREG ESP_USB_FS0_BASE

// Define Buffers
// Use DMA/Internal memory for speed.
// Size: 834 words (Data + Status) * 2 bytes
uint16_t *buf_front; // Being processed by CPU
uint16_t *buf_back;  // Being filled by I2C

uint8_t *usb_packet;

#include "esp_pm.h"

// Prevent the chip from going to sleep while USB is active
esp_pm_lock_handle_t usb_pm_lock;

void thermal_pipeline_task(void *pvParameters) {
    // 1. Initialization

    // We must ensure USB is actually initialized before proceeding
    // Note: You need to modify usb_init_cdc to return esp_err_t
    // if (usb_init_cdc() != ESP_OK) {
#if defined(CONFIG_MLX_DC_WINUSB2)
    winusbv2_init(USBD_BUSID, USBD_BASEREG);
#else // !CONFIG_MLX_DC_WINUSB2
#if defined(CONFIG_MLX_CDC_WINUSB2)
    if (winusbv2_cdc_init(0, USBD_BASEREG) != ESP_OK) {
#else  // CONFIG_MLX_CDC_VCP
    if (usb_init_cdc() != ESP_OK) {
#endif // CONFIG_MLX_CDC_WINUSB2 || CONFIG_MLX_CDC_VCP
        printf("USB Init Failed! Task suspended to prevent WDT crash.\n");
        vTaskDelete(NULL); // Stop the task here so it doesn't loop and crash the CPU
    }
#endif // CONFIG_MLX_DC_WINUSB2
    printf("[I] USB Init Success!\n");

    mlx_async_init();
    printf("[I] I2CAsync Init Success!\n");

    // Load calibration (blocking, one time)
    mlx_params_t params;
    // load_eeprom(&params);

    // Set refresh rate (e.g. 32Hz or 64Hz)
    // mlx_set_refresh_rate(0x06);

    // 2. Prime the Pipeline
    // We need one frame in the back buffer before entering the loop
    printf("[I] calling async_fetch_start\n");
    mlx_async_fetch_start(buf_back);
    printf("[I] async_fetch_start RET_OK\nStarting async_fetch_wait\n");
    mlx_async_fetch_wait(); // Wait for first frame
    printf("[I] async_fetch_wait RET_OK\n");

    // Swap immediately so 'front' has valid data
    uint16_t *temp = buf_front;
    buf_front = buf_back;
    buf_back = temp;

    // Start fetching the NEXT frame into the new 'back' buffer
    // This runs in the background while we enter the loop
    mlx_async_fetch_start(buf_back);

    while (1) {
        // --- PARALLEL SECTION START ---

        // 1. Process 'buf_front' (CPU Intensive)
        // This happens simultaneously with I2C filling 'buf_back'
        // Uses the Fixed-Point + LUT optimization
        mlx_process_subpage(buf_front, &params, usb_packet);

        // 2. Transmit USB (DMA based, non-blocking-ish)
        // printf("[I] Sending subpage over USB...");

#ifdef CONFIG_MLX_DC_WINUSB2
        usbd_winusb_send_subpage(USBD_BUSID, usb_packet);
#else // CONFIG_MLX_CDC_VCP || CONFIG_MLX_CDC_WINUSB2

        send_subpage_over_usb(usb_packet);
#endif
        // printf("\tDone.\n");

        // --- PARALLEL SECTION END ---

        // printf("CHECK1\n");
        // 3. Synchronization Point
        // We are done processing. Now we wait for I2C to finish filling 'buf_back'.
        // If processing took 10ms and I2C took 12ms, we wait 2ms.
        // If processing took 15ms and I2C took 12ms, we don't wait at all.
        mlx_async_fetch_wait();

        // 4. Swap Buffers
        temp = buf_front;
        buf_front = buf_back;
        buf_back = temp;

        // printf("CHECK2\n");

        // 5. Kick off the NEXT transfer immediately
        mlx_async_fetch_start(buf_back);

        // Optional: Yield to other tasks
        vTaskDelay(pdMS_TO_TICKS(5));
    }
}

extern void device_cdc_main(void);

void app_main(void) {
    // device_cdc_main();
    // }
    // esp_pm_lock_create(ESP_PM_CPU_FREQ_MAX, 0, "usb_lock", &usb_pm_lock);
    // esp_pm_lock_acquire(usb_pm_lock);

    // Heap allocation in internal memory is crucial for speed
    buf_front = heap_caps_malloc(834 * sizeof(uint16_t), MALLOC_CAP_DMA | MALLOC_CAP_INTERNAL);
    buf_back = heap_caps_malloc(834 * sizeof(uint16_t), MALLOC_CAP_DMA | MALLOC_CAP_INTERNAL);
    usb_packet = heap_caps_malloc(800, MALLOC_CAP_INTERNAL);

    // Create the pipeline task on Core 1 (Application Core)
    xTaskCreatePinnedToCore(thermal_pipeline_task, "pipeline", 4096, NULL, 0, NULL, 1);
}