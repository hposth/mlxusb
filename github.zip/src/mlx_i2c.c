#include "mlx_i2c.h"

// Buffer for I2C commands
static i2c_cmd_handle_t cmd;

esp_err_t mlx_read_frame_interface(uint16_t *data) {
    cmd = i2c_cmd_link_create();

    // 1. Set Start Address to 0x0400 (RAM)
    i2c_master_start(cmd);
    i2c_master_write_byte(cmd, (MLX_ADDR << 1) | I2C_MASTER_WRITE, true);
    i2c_master_write_byte(cmd, 0x04, true);
    i2c_master_write_byte(cmd, 0x00, true);

    // 2. Restart and Read 832 words (Pixels) + 2 words (Status register is at 0x8000)
    // Actually, the status register is at 0x8000, which is NOT contiguous with RAM (0x0400-0x073F).
    // We must do two transactions or read the whole block if your MLX version mirrors it.
    // Standard approach: Read RAM, then Read Status.

    i2c_master_start(cmd);
    i2c_master_write_byte(cmd, (MLX_ADDR << 1) | I2C_MASTER_READ, true);

    // Read 832 words (1664 bytes)
    // Note: This is large for a single transaction on some I2C controllers.
    // ESP32-S3 hardware FIFO is small, but the driver handles DMA/IRQs.
    i2c_master_read(cmd, (uint8_t *)data, 1664, I2C_MASTER_LAST_NACK);
    i2c_master_stop(cmd);

    esp_err_t ret = i2c_master_cmd_begin(I2C_MASTER_NUM, cmd, 100 / portTICK_PERIOD_MS);
    i2c_cmd_link_delete(cmd);

    if (ret != ESP_OK)
        return ret;

    // 3. Read Status Register (0x8000) specifically to know subpage
    cmd = i2c_cmd_link_create();
    i2c_master_start(cmd);
    i2c_master_write_byte(cmd, (MLX_ADDR << 1) | I2C_MASTER_WRITE, true);
    i2c_master_write_byte(cmd, 0x80, true);
    i2c_master_write_byte(cmd, 0x00, true);
    i2c_master_start(cmd);
    i2c_master_write_byte(cmd, (MLX_ADDR << 1) | I2C_MASTER_READ, true);
    uint8_t status_buf[2];
    i2c_master_read(cmd, status_buf, 2, I2C_MASTER_LAST_NACK);
    i2c_master_stop(cmd);

    ret = i2c_master_cmd_begin(I2C_MASTER_NUM, cmd, 100 / portTICK_PERIOD_MS);
    i2c_cmd_link_delete(cmd);

    // Store status at the end of the buffer for the processing loop
    data[833] = (status_buf[0] << 8) | status_buf[1];

    return ret;
}