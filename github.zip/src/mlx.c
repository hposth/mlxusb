#include <mlx.h>

paramsMLX90640 _params;
float          ta = -999.0;

i2c_master_bus_handle_t __mlx_bus_t;
i2c_master_dev_handle_t __mlx_dev_t;

void mlx_init(mlx_t *mlxh) {
    MLX90640_I2CInit(&__mlx_bus_t, &__mlx_dev_t);
    DBGLOG("mlx_i2c_init [0]");
    mlx_t mlx = mlx_create(__mlx_bus_t, __mlx_dev_t);
    DBGLOG("mlx_i2c_init [1]");
    *mlxh = mlx;
    DBGLOG("mlx_i2c_init [2] RET");
}

int mlx_begin(mlx_t *mlxh) {
    mlx_init(mlxh);
    if (MLX90640_I2CProbe(&__mlx_bus_t) != 0) {
        DBGLOG("[MLX90640_I2CProbe] ERR");
        return false;
    }
    // MLX90640_I2CInit(&_mlx->bus, &_mlx->dev);
    // MLX90640_I2CRead(0, MLX90640_DEVICEID1, 3,  serialNumber);

    uint16_t *eeMLX90640 =
        (uint16_t *)malloc(sizeof(uint16_t) * MLX90640_EEPROM_DUMP_NUM);

    DBGLOG("[eeMLX90640[832] ALLOC OK]");
    if (MLX90640_DumpEE(*mlxh, eeMLX90640) != 0) {
        DBGLOG("[MLX90640_DumpEE] ERR");
        return false;
    }
    DBGLOG("[MLX90640_DumpEE] OK");
#ifdef MLX90640_DEBUG
    for (int i = 0; i < 832; i++) {
        printf("0x%x, ", eeMLX90640[i]);
    }
    Serial.println();
    printf("\n");
#endif

    MLX90640_ExtractParameters(eeMLX90640, &_params);
    DBGLOG("[MLX90640_ExtractParameters] RET OK");
    // whew!
    return true;
}

float mlx_get_ta(mlx_t mlxh, bool newFrame) {
    if (!newFrame) {
        return ta;
    }
    static uint16_t mlx90640Frame[834];
    MLX90640_GetFrameData(mlxh, mlx90640Frame);
    return MLX90640_GetTa(mlx90640Frame, &_params);
}

int mlx_get_frame(mlx_t mlxh, float *framebuf) {
    float    emissivity = 0.95;
    float    tr         = 23.15;
    static uint16_t mlx90640Frame[834];
    int      status;

    for (uint8_t page = 0; page < 2; page++) {
        status = MLX90640_GetFrameData(mlxh, mlx90640Frame);

#ifdef MLX90640_DEBUG
        // Serial.printf("Page%d = [", page);
        // for (int i = 0; i < 834; i++) {
        //     Serial.printf("0x%x, ", mlx90640Frame[i]);
        // }
        // Serial.println("]");
#endif

        if (status < 0) {
            return status;
        }

        ta = MLX90640_GetTa(
            mlx90640Frame, &_params
        ); // Store ambient temp locally
        tr = ta -
             8; // OPENAIR_TA_SHIFT; // For a MLX90640 in the open air the shift
                //  is -8 degC.
#ifdef MLX90640_DEBUG
        // Serial.print("Tr = ");
        // Serial.println(tr, 8);
#endif
        MLX90640_CalculateTo(mlx90640Frame, &_params, emissivity, tr, framebuf);
    }
    return 0;
}
