#ifndef __MLX_USB_CDC_H__
#define __MLX_USB_CDC_H__

#include <stdint.h>
#include <stdbool.h>
// #include "usbd_cdc.h"
// #include "usb_cdc.h"

#include "usbd_core.h"
#include "usbd_cdc_acm.h"

#include "esp_attr.h"
#include "esp_err.h"

extern int usbd_printf(const char *format, ...);
// Define uprintf as usb_printf for consistent logging
#define uprintf(...) usbd_printf(__VA_ARGS__)

#if defined(CONFIG_MLX_CDC_VCP) || defined(CONFIG_MLX_CDC_WINUSB2)

// Define a size (2048 is standard for high-speed bulk transfer buffers)
#define CDC_WRITE_BUF_SIZE 2048
#define CDC_READ_BUF_SIZE 2048

// Add DRAM_ATTR (and alignment) to the extern declaration too!
// extern DRAM_ATTR USB_NOCACHE_RAM_SECTION USB_MEM_ALIGNX uint8_t mlx_write_buffer[2048];
// extern DRAM_ATTR USB_NOCACHE_RAM_SECTION USB_MEM_ALIGNX uint8_t mlx_read_buffer[2048];

// --- Endpoint Configurations ---
// Ensure these match your usbd_config or cherryusb_config
// #ifndef 1
// #define CDC_IN_EP 0x81
// #define CDC_OUT_EP 0x02
// #define CDC_INT_EP 0x83
// #endif // 1

esp_err_t usb_init_cdc(void);
esp_err_t winusbv2_cdc_init(uint8_t busid, uintptr_t reg_base);

bool usb_is_ready(void);

/**
 * @brief Send a raw frame buffer (Blocking or Non-blocking depending on implementation).
 * Used for the simple full-frame implementation.
 * * @param data Pointer to data.
 * @param len  Length in bytes.
 */
void usb_send_frame(uint8_t *data, uint32_t len);

/**
 * @brief Send a pre-formatted subpage packet (Optimized).
 * * @param packet_buffer Pointer to the 771-byte packet.
 */
void send_subpage_over_usb(uint8_t *packet_buffer);

#endif // CONFIG_MLX_VCP || CONFIG_MLX_CDC_WINUSB2

int usbd_printf(const char *format, ...);

#endif // __MLX_USB_CDC_H__