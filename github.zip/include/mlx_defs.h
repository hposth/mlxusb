#ifndef __DEFS_H__
#define __DEFS_H__

#define __PARAM(dir, name) CONFIG_##dir##_##name

// #define DEFINE_PARAM(name, value)                           #ifndef name
// #define name value #endif

// DEFINE_PARAM(CONFIG_I2C_NUM, I2C_NUM_0);

// PARAM(I2C, NUM)        I2C_NUM_0
#define _P_I2C_NUM     __PARAM(I2C, NUM);
#define CONFIG_I2C_NUM I2C_NUM_0
#define CONFIG_I2C_SDA GPIO_NUM_8
#define CONFIG_I2C_SCL GPIO_NUM_9
// #define CONFIG_I2C_TIMEOUT_MS      100
#define CONFIG_I2C_TIMEOUT_MS      280
#define CONFIG_I2C_MAX_BUFFER_SIZE 32
#define CONFIG_I2C_DEV_ADDR        0x33
#define CONFIG_I2C_FRQ             400000

#define MIN(a, b) ((a) < (b) ? (a) : (b))

#define DBGLOG(...) __DBGLOG(__FILE__, __LINE__, __VA_ARGS__)
// #define __DBGLOG(F, L, ...) printf("\n[%s]:%d\t%s\n", F, L, __VA_ARGS__)
#define __DBGLOG(F, L, ...)        \
    do {                           \
        printf("[%s]:%d\t", F, L); \
        printf(__VA_ARGS__);       \
        printf("\n");              \
    } while (0)

#if CONFIG_IDF_TARGET_ESP32C3
#endif

#endif