#ifndef __MLX_USB_VSC_H__
#define __MLX_USB_VSC_H__

#include "usbd_core.h"

#ifdef CONFIG_MLX_DC_WINUSB2

void usbd_winusb_in(uint8_t busid, uint8_t ep, uint32_t nbytes);
void usbd_winusb_out(uint8_t busid, uint8_t ep, uint32_t nbytes);

void winusbv2_init(uint8_t busid, uintptr_t reg_base);

void usbd_winusb_send_subpage(uint8_t busid, uint8_t *packet_buffer);

#endif // CONFIG_MLX_DC_WINUSB2
#endif // __MLX_USB_VSC_H__