#ifndef __MLX_USB_CONFIG_H__
#define __MLX_USB_CONFIG_H__

// // ESP32-S3 Specific Setup
// #define CONFIG_USB_DWC2_PORT 0               // Use Internal USB FS PHY
// #define USBD_IRQHandler dwc2_usb_irq_handler // Link IRQ to Driver

// // Generic Stack Config
// #define CONFIG_USBDEV_EP_NUM 4 // Number of Endpoints (S3 has 6, but 4 is enough)
// #define CONFIG_USBDEV_MAX_BUS_POWER 100

// #define CONFIG_USB_ALIGN_SIZE 4

#define USB_CONFIG_DESCRIPTOR_SIZE 9
#define USB_INTERFACE_DESCRIPTOR_SIZE 9
#define USB_ENDPOINT_DESCRIPTOR_SIZE 7

// #define CONFIG_USB_PRINTF(...) esp_rom_printf(__VA_ARGS__)

#ifndef CONFIG_USB_DBG_LEVEL
#define CONFIG_USB_DBG_LEVEL USB_DBG_LOG
#endif

/* Enable print with color */
#define CONFIG_USB_PRINTF_COLOR_ENABLE

// #define CONFIG_USB_POWER_SOURCE USB_CONFIG_SELF_POWERED
// // #define CONFIG_USB_POWER_SOURCE USB_CONFIG_BUS_POWERED

#endif /* MLX_USB_CONFIG_H */