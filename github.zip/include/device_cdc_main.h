#ifndef __DEVICE_CDC_MAIN_H__
#define __DEVICE_CDC_MAIN_H__

void device_cdc_main(void);

#endif /* __DEVICE_CDC_MAIN_H__ */