#ifndef __MLX_MATH_H__
#define __MLX_MATH_H__

#include <stdint.h>
#include "mlx_i2c.h" // Requires definition of mlx_params_t

// --- Fixed Point Math Constants ---
#define FIXED_SCALE_Q16 65536
#define FIXED_SHIFT_Q16 16

// --- Math Helpers ---
// Integer Square Root (Optimized for 32-bit)
uint32_t isqrt32(uint32_t n);

// Fixed-point 4th root approximation
int32_t calc_temp_fixed(int32_t v_ir, int32_t emissivity_fixed);

// --- Full Frame Processor (Blocking/Standard Mode) ---
// Use this if you are NOT using the subpage/interleaved optimization
// output_image: Buffer of size 768 (int16_t)
void mlx_calculate_frame(uint16_t *raw_frame_data, mlx_params_t *params, int16_t *output_image);

#endif // __MLX_MATH_H__