/**
 * @copyright (C) 2017 Melexis N.V.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
#ifndef __MLX90640_I2C_H__
#define __MLX90640_I2C_H__

#include <stdint.h>

#include "mlx_defs.h"

#include "mlx_types.h"

#include "driver/i2c.h"
#include "driver/i2c_master.h"
#include "esp_err.h"

// #ifndef CONFIG_I2C_SDA
// #define CONFIG_I2C_SDA GPIO_NUM_4
// #endif // !CONFIG_I2C_SDA
// #ifndef CONFIG_I2C_SCL
// #define CONFIG_I2C_SCL GPIO_NUM_5
// #endif // !CONFIG_I2C_SCL

#define MLX90640_I2C_MODE_R 1
#define MLX90640_I2C_MODE_W 0

extern int  MLX90640_I2CProbe(i2c_master_bus_handle_t *bus_handle);
extern void MLX90640_I2CInit(
    i2c_master_bus_handle_t *bus_handle, i2c_master_dev_handle_t *dev_handle
);
extern int MLX90640_I2CStartTransmission(mlx_t mlxh, uint8_t mode);
extern int MLX90640_I2CGeneralReset(void);
extern int MLX90640_I2CRead(
    mlx_t mlxh, uint16_t startAddress, uint16_t nMemAddressRead, uint16_t *data
);
extern int  MLX90640_I2CReadTest(mlx_t mlxh, uint8_t *data, uint16_t reg_addr);
extern int  MLX90640_I2CWrite(mlx_t mlxh, uint16_t writeAddress, uint16_t data);
extern void MLX90640_I2CFreqSet(int freq);
#endif