#ifndef __MLX90640_USBD_H__
#define __MLX90640_USBD_H__

#include <stdio.h>
#include <string.h>
#include <sys/fcntl.h>
#include <sys/errno.h>
#include <sys/unistd.h>
#include <sys/select.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"

#include "usbd_core.h"
#include "usbd_cdc.h"

static const char *TAG = "mlx_usbd";

// Configuration constants
#define IMAGE_SIZE (32 * 24 * 4) // Example: MLX90640 frame (768 floats = 3072 bytes)
__attribute__((aligned(CONFIG_USB_ALIGN_SIZE))) uint8_t mlx_usbd_image_buffer[IMAGE_SIZE];

// Synchronization Primitives
SemaphoreHandle_t mlx_usbd_tx_ready; // "Hey USB, I have a frame for you"
SemaphoreHandle_t mlx_usbd_capture_ready;

// Initialize the USB CDC device for transmitting MLX90640 data
void mlx_usbd_init();

// Transmit a frame of thermal data over USB CDC
void mlx_usbd_transmit_frame(float *frame_data, size_t frame_size);

void mlx_usbd_task(void *param);

#endif //__MLX90640_USBD_H__