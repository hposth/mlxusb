#ifndef __MLX90640_H__
#define __MLX90640_H__

#include "MLX90640_API.h"
#include "driver/i2c_types.h"
#include "mlx_types.h"
#include "mlx_hal.h"

void mlx_init(mlx_t *mlxh);
int  mlx_begin(mlx_t *mlxh);

float mlx_get_ta(mlx_t mlxh, bool newFrame);
int   mlx_get_frame(mlx_t mlxh, float *framebuf);

#endif