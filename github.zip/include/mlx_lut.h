#ifndef __MLX_LUT_H__
#define __MLX_LUT_H__

#include <stdint.h>
#include "lut_data.h" // Generated LUT data

// LUT Size: 2048 entries provides good granularity without eating all RAM
#define TEMP_LUT_SIZE 2048
// Input Energy Offset (to handle negative values in array index)
#define LUT_OFFSET 1000

// This array maps "Compensated IR Energy" to "Centi-Degrees Celsius"
// We declare it extern here and define it in the .c file.
// In a real app, you might generate this at startup to save Flash space,
// or hardcode it to save startup time.
extern const int16_t temp_lut[TEMP_LUT_SIZE];

// Helper to look up temperature
static inline int16_t lookup_temp(int32_t energy_val) {
    int32_t index = energy_val + LUT_OFFSET;

    // Clamp to table bounds
    if (index < 0)
        index = 0;
    if (index >= TEMP_LUT_SIZE)
        index = TEMP_LUT_SIZE - 1;

    return temp_lut[index];
}

#endif // __MLX_LUT_H__