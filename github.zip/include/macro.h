#ifndef __MACRO_H__
#define __MACRO_H__

#include <stdio.h>

/*
 * The color for terminal (foreground)
 * BLACK    30
 * RED      31
 * GREEN    32
 * YELLOW   33
 * BLUE     34
 * PURPLE   35
 * CYAN     36
 * WHITE    37
 */

#define TRACEF_CN_BLACK 30
#define TRACEF_CN_RED 31
#define TRACEF_CN_GREEN 32
#define TRACEF_CN_YELLOW 33
#define TRACEF_CN_BLUE 34
#define TRACEF_CN_PURPLE 35
#define TRACEF_CN_CYAN 36
#define TRACEF_CN_WHITE 37

#define __tracef__(...) esp_rom_printf(__VA_ARGS__)

#define _TRACEF_COLOR(n) __tracef__("\033[" #n "m")
#define _TRACEF_HDR(func, color_n) __tracef__("\033[" #color_n "m[" func "/" USB_DBG_TAG "] ")
#define _TRACEF_X_END __tracef__("\033[0m")

#define tracef_line(func, color_n, fmt, ...)                                                                                                                   \
    do {                                                                                                                                                       \
        _TRACEF_HDR(func, color_n);                                                                                                                            \
        __tracef__(fmt, ##__VA_ARGS__);                                                                                                                        \
        _TRACEF_X_END;                                                                                                                                         \
    } while (0)

#ifndef tracef
#define tracef(func, color_n, format, ...)                                                                                                                     \
    do {                                                                                                                                                       \
        if (defined(TRACE_##func) && TRACE_##func) {                                                                                                           \
            tracef_line(func, color_n, format, ##__VA_ARGS__);                                                                                                 \
        } else {                                                                                                                                               \
            tracef_line("NF", color_n, format, ##__VA_ARGS__);                                                                                                 \
        }                                                                                                                                                      \
    } while (0)
#endif
// (if (defined(TRACE_##tag) && TRACE_##tag){esp_rom_printf("[%s:%d]"##format, __FILE_NAME__, __LINE__, VA_OPT__(, ) __VA_ARGS__)})
// #endif

#endif // __MACRO_H__