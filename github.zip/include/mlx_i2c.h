#ifndef __MLX_I2C_H__
#define __MLX_I2C_H__

#include <stdint.h>
#include "driver/i2c.h"

// Configuration
#define I2C_MASTER_SCL_IO 2
#define I2C_MASTER_SDA_IO 1
#define I2C_MASTER_NUM 0
#define I2C_MASTER_FREQ_HZ 1000000 // 1MHz Fast Mode+
#define MLX_ADDR 0x33

// Fixed Point Scaling (Q16.16)
#define FIXED_SCALE 65536
#define FLOAT_TO_FIXED(x) ((int32_t)((x) * FIXED_SCALE))
#define FIXED_TO_INT(x) ((x) / FIXED_SCALE)

typedef struct {
    int16_t  kVdd;
    int16_t  vdd25;
    float    KvPTAT; // Kept as float for coeff init, converted later
    float    KtPTAT;
    uint16_t vPTAT25;
    float    alphaPTAT;
    int16_t  gainEE;
    float    tgc;
    int16_t  offset[768];
    int16_t  alpha[768]; // Scaled
    int8_t   kv[768];
    int8_t   kta[768];
} mlx_params_t;

// Initialize I2C
void      i2c_init_fast();
// Read full frame (832 words)
esp_err_t mlx_read_frame(uint16_t *data);
// Write configuration
esp_err_t mlx_set_refresh_rate(uint8_t rate_hz);

// --- Async / DMA-like Interface ---

/**
 * @brief Initialize the high-priority I2C worker task and synchronization primitives.
 * Call this once before the main loop.
 */
void mlx_async_init(void);

/**
 * @brief Non-blocking call to start fetching the next frame.
 * This wakes up the worker task to perform the I2C transaction in the background.
 * * @param buffer Pointer to the buffer (internal RAM) where data will be stored.
 * Must be at least 834 words (1668 bytes) to hold pixels + status.
 */
void mlx_async_fetch_start(uint16_t *buffer);

/**
 * @brief Blocking wait for the current background transfer to complete.
 * Call this after you finish processing the *previous* frame to ensure the
 * *new* frame is fully loaded before swapping buffers.
 */
void mlx_async_fetch_wait(void);

#endif // __MLX_I2C_H__