#ifndef __MLX_TYPES_H__
#define __MLX_TYPES_H__

#include "driver/i2c_master.h"
#include "driver/i2c_types.h"

#define __test

struct mlx_dev_t {
    i2c_master_dev_handle_t dev;
    i2c_master_bus_handle_t bus;
};
typedef struct mlx_dev_t *mlx_t;

#endif