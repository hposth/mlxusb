#ifndef __MLX90640_HAL_H__
#define __MLX90640_HAL_H__

#include <stdint.h>
#include <freertos/FreeRTOS.h>

#include "mlx_defs.h"

// #include "driver/i2c.h"
#include "driver/i2c_master.h"
#include "driver/i2c_types.h"
#include "mlx_types.h"
#include "esp_err.h"

mlx_t mlx_create(i2c_master_bus_handle_t bus, i2c_master_dev_handle_t dev);
// int   mlx_hal_read(mlx_t mlxh, uint16_t reg, uint16_t nbytes, uint16_t
// *data); int   mlx_hal_write(mlx_t mlxh, uint16_t reg, uint16_t data);

#endif