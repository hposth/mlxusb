#ifndef __MLX_PROCESS_H__
#define __MLX_PROCESS_H__

#include <stdint.h>
#include "mlx_i2c.h"

// --- Constants ---
#define MLX_PIXEL_COUNT 768
#define USB_PACKET_SIZE 771

// --- State Tracking Structure ---
// The MLX90640 updates Ta (Ambient Temp) and Vdd every subpage.
// However, accurate pixel compensation often requires a stable Ta.
// We store the values here to smooth them or use the previous subpage's values
// if the current reading is noisy.
typedef struct {
    int32_t vdd;          // Current Vdd (Fixed Point)
    int32_t ta;           // Current Ta (Fixed Point)
    int32_t ta4_comp;     // Ta^4 Compensation Factor (Fixed Point)
    uint8_t last_subpage; // Track which subpage we processed last (0 or 1)
} mlx_frame_state_t;

// --- Function Prototypes ---
void mlx_process_subpage(uint16_t *raw_data, mlx_params_t *params, uint8_t *usb_packet);

#endif // __MLX_PROCESS_H__