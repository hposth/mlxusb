import serial
import struct
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import animation
import time

# --- Configuration ---
SERIAL_PORT = (
    "COM10"  # Change this to your ESP32-S3 USB port (e.g., /dev/ttyACM0 on Linux)
)
BAUD_RATE = (
    2000000  # CDC is virtual, but higher baud ensures driver buffers fast enough
)
FRAME_WIDTH = 32
FRAME_HEIGHT = 24
TOTAL_PIXELS = FRAME_WIDTH * FRAME_HEIGHT
PAYLOAD_SIZE = 768  # 384 pixels * 2 bytes
PACKET_SIZE = 771  # 2 (Head) + 1 (ID) + 768 (Data)

# --- Pre-calculate Checkerboard Masks ---
# The MLX90640 updates pixels in a checkerboard pattern.
# We create boolean masks to easily map the linear stream to the 2D array.
rows, cols = np.indices((FRAME_HEIGHT, FRAME_WIDTH))
checkerboard_sum = rows + cols
mask_subpage_0 = (checkerboard_sum % 2) == 0
mask_subpage_1 = (checkerboard_sum % 2) == 1

# Buffer to hold the full thermal image
full_frame = np.zeros((FRAME_HEIGHT, FRAME_WIDTH), dtype=np.float32)

# Initialize Serial
try:
    ser = serial.Serial(SERIAL_PORT, BAUD_RATE, timeout=0.1)
    print(f"Connected to {SERIAL_PORT}")
    ser.reset_input_buffer()
except Exception as e:
    print(f"Error opening serial port: {e}")
    exit()

# --- Visualization Setup ---
fig, ax = plt.subplots()
img_display = ax.imshow(
    full_frame, cmap="inferno", interpolation="bilinear", vmin=20, vmax=40
)
cbar = plt.colorbar(img_display)
cbar.set_label("Temperature (°C)")
ax.set_title("MLX90640 Thermal Stream")


def find_packet_start():
    """Synchronize with the stream by looking for 0xDE 0xAD"""
    while True:
        # Read byte by byte until we find header
        b1 = ser.read(1)
        if b1 == b"\xde":
            b2 = ser.read(1)
            if b2 == b"\xad":
                return True


def update(frame):
    # Read as much data as possible to clear buffer lag
    # We want the LATEST frame, so if buffer is huge, skip
    if ser.in_waiting > PACKET_SIZE * 4:
        ser.reset_input_buffer()

    # Sync with header
    if not find_packet_start():
        return (img_display,)

    # Read Subpage ID (1 byte)
    subpage_id_byte = ser.read(1)
    if len(subpage_id_byte) < 1:
        return (img_display,)
    subpage_id = ord(subpage_id_byte)

    # Read Payload (768 bytes)
    payload_raw = ser.read(PAYLOAD_SIZE)
    if len(payload_raw) != PAYLOAD_SIZE:
        return (img_display,)

    # Unpack binary data to Int16 array
    # '<' = little-endian, 'h' = short (2 bytes) * 384 pixels
    pixels_1d = np.array(struct.unpack("<" + "h" * 384, payload_raw), dtype=np.float32)

    # Convert Centi-degrees to Degrees
    pixels_1d /= 100.0

    # Update the specific checkerboard pixels
    if subpage_id == 0:
        full_frame[mask_subpage_0] = pixels_1d
    else:
        full_frame[mask_subpage_1] = pixels_1d

    # Update Plot
    img_display.set_array(full_frame)

    # Auto-scale colors slightly for better contrast (optional)
    # vmin, vmax = np.min(full_frame), np.max(full_frame)
    # img_display.set_clim(vmin=vmin, vmax=vmax)

    return (img_display,)


# Run Animation
ani = animation.FuncAnimation(
    fig, update, interval=1, blit=True, cache_frame_data=False
)
plt.show()

# Clean exit
ser.close()
