import serial
import serial.tools.list_ports


mainports = list(serial.tools.list_ports.grep("", include_links=True))
# for port, desc, hwid in sorted(mainports):
#     print(f"{port}: {desc} [{hwid}]")
comports = serial.tools.list_ports.comports()
for port, desc, hwid in sorted(comports):
    print(f"{port}: {desc} [{hwid}]")

ser = serial.Serial("COM3", 38400, timeout=0, parity=serial.PARITY_EVEN)
s = ser.read(100)  # read up to one hundred bytes
# or as much is in the buffer
pass
