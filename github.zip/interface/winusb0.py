"""Test2: PL2303 serial port user-space driver using WINUSB high level api"""

import time, keyboard
from winusbpy import *


# usb = winusbpy.WinUsbPy()
# devices = usb.list_usb_devices()
# print(f"Found {len(devices)} USB devices.")
# for i, device in enumerate(devices):
#     print(f"Device {i}: {device}")

# Find device using the 0xFFFF IDs from the C code
# dev = usb.core.find(idVendor=0xFFFF, idProduct=0xFFFF)
# if dev is None:
#     raise ValueError("Device not found")
# print(f"Device found: {dev._get_full_descriptor_str()}")

# dev.set_configuration()

# # # Read the image buffer (match the size in main.c)
# # image_data = dev.read(0x81, 153600, timeout=5000)
# # print(f"Received {len(image_data)} bytes!")

# # get an endpoint instance
# cfg = dev.get_active_configuration()
# intf = cfg[(0, 0)]

# ep = usb.util.find_descriptor(
#     intf,
#     # match the first OUT endpoint
#     custom_match=lambda e: usb.util.endpoint_direction(e.bEndpointAddress)
#     == usb.util.ENDPOINT_IN,
# )

# assert ep is not None

# # write the data
# # usb.core.Endpoint.read(ep, size, timeout)
# x = ep.read(4, timeout=5000)
# print("Data read successfully")
# pass


# pl2303_vid = "2309"
# pl2303_pid = "0606"
pl2303_vid = "FFFE"
pl2303_pid = "FFFF"

# 12 13 16 17 20

""" USB Setup Packets """
pkt1 = UsbSetupPacket(0xC0, 0x01, 0x8484, 0x00, 0x01)
pkt2 = UsbSetupPacket(0x40, 0x01, 0x0404, 0x00, 0x00)
pkt3 = UsbSetupPacket(0x40, 0x01, 0x0404, 0x00, 0x01)
pkt4 = UsbSetupPacket(0xC0, 0x01, 0x8383, 0x00, 0x01)
pkt5 = UsbSetupPacket(0xC0, 0x01, 0x8484, 0x00, 0x01)
pkt6 = UsbSetupPacket(0x40, 0x01, 0x0404, 0x01, 0x00)
pkt7 = UsbSetupPacket(0xC0, 0x01, 0x8484, 0x00, 0x01)
pkt8 = UsbSetupPacket(0xC0, 0x01, 0x8383, 0x00, 0x01)
pkt9 = UsbSetupPacket(0x40, 0x01, 0x0000, 0x01, 0x00)
pkt10 = UsbSetupPacket(0x40, 0x01, 0x0001, 0x00, 0x00)
pkt11 = UsbSetupPacket(0x40, 0x01, 0x0002, 0x44, 0x00)
pkt12 = UsbSetupPacket(0x00, 0x01, 0x0001, 0x00, 0x00)

pkt13 = UsbSetupPacket(0x21, 0x20, 0x0000, 0x00, 0x07)
pkt14 = UsbSetupPacket(0x40, 0x01, 0x0505, 0x1311, 0x00)
pkt15 = UsbSetupPacket(0x21, 0x22, 0x0001, 0x00, 0x00)
pkt16 = UsbSetupPacket(0x40, 0x01, 0x0505, 0x1311, 0x00)
pkt17 = UsbSetupPacket(0x21, 0x22, 0x0001, 0x00, 0x00)
pkt18 = UsbSetupPacket(0xC0, 0x01, 0x0080, 0x00, 0x02)
pkt19 = UsbSetupPacket(0xC0, 0x01, 0x0081, 0x00, 0x02)
pkt20 = UsbSetupPacket(0x40, 0x01, 0x0000, 0x01, 0x00)

""" USB Data """
hello = b"Hello"
header = b"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x08\x00\x00\x01\x08\x01\x00\x00\x08\x01\x00\x00\x08\x01\x00\x00\x08\x01\x00\x00\x08\x01\x00\x00\x08\x01\x00\x00\x08\x01\x00\x00"
tx1 = b"\x18"
tx2 = b"\x08"
tx3 = b"\x08"
tx4 = b"\x14"
tx5 = b"\x14"
tx6 = b"\x22"
tx7 = b"\x3e"
tx8 = b"\x22"
tx9 = b"\x77"
tx10 = b"\x00"
tx11 = b"\x00"
tx12 = b"\x00"

index = 0
api = WinUsbPy()


def tryFind(**kwargs):
    result = api.list_usb_devices(**kwargs)
    global index
    if result:
        p = result.values().__iter__().__next__()
        print(f"[{index}] {p}")
        index += 1
        return p
    else:
        print(f"[{index}] No Usb devices connected")
        index += 1
        return None


results = []
# results.append(tryFind(present=True))
# results.append(tryFind(default=True))
# results.append(tryFind(allclasses=True))
# results.append(tryFind(profile=True))
results.append(tryFind(deviceinterface=True))
result = results[0] or results[1] or results[2] or results[3] or results[4]
# result = api.list_usb_devices(present=True, allclasses=True)
# if result:
#     p = result.values().__iter__().__next__()
#     print(p)
# ret = api.find_device(p)  # (0, pl2303_vid, pl2303_pid)
# ret = api.find_device(result)  # (0, pl2303_vid, pl2303_pid)
# ret = api.init_winusb_device("09CB", "1996")
ret = api.init_winusb_device("303A", "4001")
# if True:
#     ret = api.init_winusb_device(pl2303_vid, pl2303_pid)
if ret:  # "CherryUSB WINUSB DEMO"
    speed = api.query_device_info(query=1)
    if speed != -1:
        print("Device Speed: " + str(speed))
    else:
        print("Device speed could not be obtained")

    interface_descriptor = api.query_interface_settings(0)

    if interface_descriptor != None:
        print("bLength: " + str(interface_descriptor.b_length))
        print("bDescriptorType: " + str(interface_descriptor.b_descriptor_type))
        print("bInterfaceNumber: " + str(interface_descriptor.b_interface_number))
        print("bAlternateSetting: " + str(interface_descriptor.b_alternate_setting))
        print("bNumEndpoints " + str(interface_descriptor.b_num_endpoints))
        print("bInterfaceClass " + str(interface_descriptor.b_interface_class))
        print("bInterfaceSubClass: " + str(interface_descriptor.b_interface_sub_class))
        print("bInterfaceProtocol: " + str(interface_descriptor.b_interface_protocol))
        print("iInterface: " + str(interface_descriptor.i_interface))

    pipe_info_list = map(api.query_pipe, range(interface_descriptor.b_num_endpoints))
    for item in pipe_info_list:
        print("PipeType: " + str(item.pipe_type))
        print("PipeId: " + str(item.pipe_id))
        print("MaximumPacketSize: " + str(item.maximum_packet_size))
        print("Interval: " + str(item.interval))

    """
    buff = None -> Buffer length will be zero. No data expected
    """
    # api.control_transfer(pkt1, buff=[0])
    # api.control_transfer(pkt2, buff=None)
    # api.control_transfer(pkt3, buff=[0])
    # api.control_transfer(pkt4, buff=[0])
    # api.control_transfer(pkt5, buff=[0])
    # api.control_transfer(pkt6, buff=None)
    # api.control_transfer(pkt7, buff=[0])
    # api.control_transfer(pkt8, buff=[0])
    # api.control_transfer(pkt9, buff=None)
    # api.control_transfer(pkt10, buff=None)
    # api.control_transfer(pkt11, buff=None)
    # api.control_transfer(pkt12, buff=None)
    # api.control_transfer(pkt13, buff=[0xC0, 0x12, 0x00, 0x00, 0x00, 0x00, 0x08])
    # api.control_transfer(pkt14, buff=None)
    # api.control_transfer(pkt15, buff=None)
    # api.control_transfer(pkt16, buff=None)
    # api.control_transfer(pkt17, buff=None)
    # api.control_transfer(pkt18, buff=[0, 0])
    # api.control_transfer(pkt19, buff=[0, 0])
    # api.control_transfer(pkt20, buff=None)

    # api.write(0x02, hello)
    time.sleep(0.045)
    # api.write(0x02, header)
    # time.sleep(0.380)
    # api.write(0x02, hello)
    # time.sleep(0.380)
    # print(r"\x" + r"\x".join(f"{b:02x}" for b in hello))
    # api.write(0x02, tx1)
    # time.sleep(0.380)
    # api.write(0x02, tx2)
    # time.sleep(0.380)
    # api.write(0x02, tx3)
    # time.sleep(0.380)
    # api.write(0x02, tx4)
    # time.sleep(0.380)
    # api.write(0x02, tx5)
    # time.sleep(0.380)
    # api.write(0x02, tx6)
    # time.sleep(0.380)
    # api.write(0x02, tx7)
    # time.sleep(0.380)
    # api.write(0x02, tx8)
    # time.sleep(0.380)
    # api.write(0x02, tx9)
    # time.sleep(0.380)
    # api.write(0x02, tx10)
    # time.sleep(0.380)
    # api.write(0x02, tx11)
    # time.sleep(0.380)
    # api.write(0x02, tx12)
    keyboard.on_press_key(
        "p",
        lambda _: (
            api.write(0x02, hello) > 0,
            print(hello),
        ),
    )
    # keyboard.on_press_key("p", lambda _: print(hello))
    while True:
        print("\n\nStarting to read data...\n")
        # request = api.write(0x02, hello)
        readbuf = api.read(0x81, 64)
        if readbuf != None:
            print(f"{' '.join(f'{b:02x}' for b in bytes(readbuf))}")
        # else:
        # print(".")
        # break
        # time.sleep(0.5)
        # _ori_ena = api.overlapped_read_init(0x81, 64)
        # if _ori_ena:
        #     print(f"Overlapped Read Init started on pipe {0x81:02x}.")
        #     while True:
        #         buf = api.overlapped_read(0x81)
        #         # api.change_interface()
        #         if buf != None:
        # print(f"Data read: {' '.join(f'{b:02x}' for b in buf)}'")
        #         else:
        #             print("No data read (timeout or error).")
        #             break
        # else:
        #     print("Overlapped Read Init failed.")
else:
    print("PL2303 could not be init")

# else:
#     print("No Usb devices connected")
